import 'package:flutter/material.dart';
import 'package:login_ui/pages/loginPage.dart';
import 'package:login_ui/pages/signUpPage.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);
  static const String id = 'home_page';

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Map<String, String> uis = {
    Lesson.id: 'Login Page',
    SignUpPage.id: 'Sign Up Page',
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 33, 37, 116),
        foregroundColor: Color.fromARGB(255, 224, 190, 52),
        title: const Text(
            '***QUARSHIE FRANCIS(10909989) ***** ASSIGNMENT 3 (BASIC FLUTTER APP)'),
        centerTitle: true,
      ),
      body: SizedBox(
        height: MediaQuery.of(context).size.height,
        child: ListView.builder(
          itemCount: uis.length,
          itemBuilder: (context, index) {
            return _card(index + 1, uis.values.toList()[index],
                uis.keys.toList()[index]);
          },
        ),
      ),
    );
  }

  Widget _card(int number, String name, String id) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 25, vertical: 8),
      child: MaterialButton(
        child: ListTile(
          contentPadding: const EdgeInsets.all(0),
          minVerticalPadding: 15,
          minLeadingWidth: 15,
          leading: Text(number.toString(),
              style: const TextStyle(
                  fontWeight: FontWeight.bold, letterSpacing: 2)),
          title: Center(
              child: Text(name,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, letterSpacing: 1.5),
                  textAlign: TextAlign.center)),
          selectedColor: Color.fromARGB(255, 98, 196, 18),
        ),
        onPressed: () {
          Navigator.of(context).pushNamed(id);
        },
      ),
      elevation: 10.0,
    );
  }
}
