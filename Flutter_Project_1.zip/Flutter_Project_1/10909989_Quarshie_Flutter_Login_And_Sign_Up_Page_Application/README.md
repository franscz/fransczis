# SIGN IN & SIGN UP UI


- Text Fields
- Box Shadow
- Gradient
- resizeToAvoidBottomInset
- Rich Text
- Flutter Toast

![This is an image](assets/readme/img.png)

![This is an image](assets/readme/img_1.png)
